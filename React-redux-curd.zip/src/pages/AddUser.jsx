import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { addUser } from '../redux/actions'
import { useNavigate } from "react-router-dom";

function AddUser() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [contact, setContact] = useState('');
    const [address, setAddress] = useState('');

    let dispatch = useDispatch();
    let navigate = useNavigate();

    const submit = (e) => {
        console.log(e.target);
        e.preventDefault();
        let payload={
            name:name,
            email:email,
            contact:contact,
            address:address
        }
        console.log("data=>",payload);
        dispatch(addUser(payload));
        navigate("/");
    }



    return (
        <div className='add-user'>
            <center><h2>Add User</h2></center>

            <form onSubmit={submit}>

                <div className='form-group'>
                    <label>Name</label>
                    <br></br>
                    <input type="text" name="name"
                        onChange={e => setName(e.target.value)}
                    />
                </div>
                <div className='form-group'>
                    <label>Address</label>
                    <br></br>
                    <input type="text" name="address"
                        onChange={e => setAddress(e.target.value)}
                    />
                </div>
                <div className='form-group'>
                    <label>Email</label>
                    <br></br>
                    <input type="text" name="email"
                        onChange={e => setEmail(e.target.value)}
                    />
                </div>
                <div className='form-group'>
                    <label>Contact</label>
                    <br></br>
                    <input type="phone" name="contact"
                        onChange={e => setContact(e.target.value)}
                    />
                </div>
                <div className='submit-btn'>
                    <button type="submit" className='submit-button'>Save</button>
                </div>
            </form>


        </div>
    )
}

export default AddUser