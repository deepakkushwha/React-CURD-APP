import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { getSingleUser, updateUser } from '../redux/actions'
import { useNavigate, useParams } from "react-router-dom";

function EditUser() {
   
    const [state, setState] = useState({
        name: "",
        email: "",
        contact: "",
        address: "",
    });

    const{name, email, contact, address} = state;

    const handleInputChange = (e) =>{
        let {name,value} =e.target;
        setState({...state, [name]:value})
    }

    let dispatch = useDispatch();
    let navigate = useNavigate();
    let { id } = useParams();
    const { user } = useSelector((state) => state.users)
useEffect(()=>{
    if(user){
        setState({...user});
    }
},[user]);

    const submit = (e) => {
        e.preventDefault();
        dispatch(updateUser(state,id));
        navigate("/");
    }

    useEffect(() => {
        dispatch(getSingleUser(id))
    }, [])

    return (
        <div className='add-user'>
            <center><h2>Update User</h2></center>

            <form onSubmit={submit}>

                <div className='form-group'>
                    <label>Name</label>
                    <br></br>
                    <input type="text" name="name" defaultValue={name}
                        onChange={handleInputChange}
                    />
                </div>
                <div className='form-group'>
                    <label>Address</label>
                    <br></br>
                    <input type="text" name="address" defaultValue={address}
                       onChange={handleInputChange}
                    />
                </div>
                <div className='form-group'>
                    <label>Email</label>
                    <br></br>
                    <input type="text" name="email" defaultValue={email}
                     onChange={handleInputChange}
                    />
                </div>
                <div className='form-group'>
                    <label>Contact</label>
                    <br></br>
                    <input type="phone" name="contact" defaultValue={contact}
                     onChange={handleInputChange}
                    />
                </div>
                <div className='submit-btn'>
                    <button type="submit" className='submit-button'>Update</button>
                </div>
            </form>
        </div>
    )
}

export default EditUser