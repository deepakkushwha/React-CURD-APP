import React from 'react'
import { useNavigate } from "react-router-dom";

function Header() {
  let navigate = useNavigate();
  function addUser(){
    navigate("/addUser");
  }
  return (
    <>
    <div className="header">
  <a href="#default" className="logo">Redux</a>
  <div className="header-right">
    <a className="active" href="/">Home</a>
    <a onClick={addUser}>Add</a>
    {/* <a href="#about">About</a> */}
  </div>
</div>
</>
  )
}

export default Header