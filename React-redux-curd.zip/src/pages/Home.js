import React,{useEffect} from 'react';
import {useDispatch, useSelector} from "react-redux";
import { deleteUser, loadUsers } from '../redux/actions';
import { useNavigate } from "react-router-dom";


const Home = () => {
    let dispatch = useDispatch();
    let navigate = useNavigate();

    const {users} = useSelector(state => state.users)

    useEffect(()=>{
        dispatch(loadUsers());
    },[]);

    const handleDelete = (id) => {
    if(window.confirm('Are you sure wanted to delete the user ?')){
        dispatch(deleteUser(id));
    }
    }
    const handleEdit = (id) => {
        navigate(`/editUser/${id}`);
    }
    
function go(){
  navigate("/AddContact");
}
  return (
    <div>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                { users && users.map((data)=>(
                <tr key={data.id}>
                    <td>{data.name}</td>
                    <td>{data.email}</td>
                    <td>{data.contact}</td>
                    <td>{data.address}</td>
                    <td>
                        <button style={{marginRight:"5px"}} onClick={()=>handleEdit(data.id)}>Edit</button>
                        <button  onClick={()=>handleDelete(data.id)}>Delete</button>
                    </td>
                </tr>
           
                ))}
                 </tbody>
        </table>
    </div>
  )
}

export default Home